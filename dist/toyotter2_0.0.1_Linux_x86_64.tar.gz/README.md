# toyotter2

Golang製のCUIベースTwitterクライアント

## インストール

```
$ go get github.com/KeisukeToyota/toyotter2
$ cp $GOPATH/src/github.com/KeisukeToyota/toyotter2/.env.example ~/.env.toyotter 
```

`.env.toyotter` にキーの設定をしてください

## 使い方
`$ toyotter2 --help` を参照してください
